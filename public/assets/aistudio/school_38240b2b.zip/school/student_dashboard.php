<?php
require_once __DIR__ . '/config/session.php';
start_app_session();

if (($_SESSION['role'] ?? null) !== 'student' || empty($_SESSION['student_id'])) {
    header('Location: student_portal%20login.html');
    exit;
}

require_once __DIR__ . '/config/database.php';

$statement = $pdo->prepare(
    "SELECT student_id, full_name, class, programme, status
     FROM students
     WHERE student_id = :student_id AND status = 'Active'
     LIMIT 1"
);
$statement->execute(['student_id' => $_SESSION['student_id']]);
$student = $statement->fetch();

if (!$student) {
    $_SESSION = [];
    session_destroy();
    header('Location: student_portal%20login.html?error=invalid');
    exit;
}

$escape = static fn ($value): string => htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$studentName = $student['full_name'];
$studentClass = trim(implode(' ', array_filter([$student['class'], $student['programme']])));
if ($studentClass === '') {
    $studentClass = 'Not assigned';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Dashboard | Nkroful Agricultural Secondary Technical School</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root {
    --sidebar-bg: #14294b;
    --sidebar-hover: #1e3a66;
    --sidebar-active: #2b4c7e;
    --bg-main: #f4f6f9;
    --white: #ffffff;
    --text-main: #111827;
    --text-muted: #6b7280;
    --gold: #d9b84a;
    --blue-banner-start: #102a56;
    --blue-banner-end: #1a3c73;
    --yellow-bg: #fef3c7;
    --yellow-text: #92400e;
    --gray-bg: #f3f4f6;
    --gray-text: #4b5563;
}

* { box-sizing: border-box; margin: 0; padding: 0; }

body {
    font-family: 'Inter', sans-serif;
    background-color: var(--bg-main);
    color: var(--text-main);
    display: flex;
    min-height: 100vh;
}

.sidebar {
    width: 260px;
    background-color: var(--sidebar-bg);
    color: var(--white);
    display: flex;
    flex-direction: column;
    position: fixed;
    top: 0; bottom: 0; left: 0;
    z-index: 10;
}

.brand {
    padding: 24px;
    display: flex;
    align-items: center;
    gap: 12px;
    border-bottom: 1px solid rgba(255,255,255,0.05);
}

.brand img {
    height: 40px;
    border-radius: 50%;
}

.brand-text {
    font-size: 10px;
    font-weight: 600;
    line-height: 1.4;
    letter-spacing: 0.5px;
}

.portal-label {
    color: var(--gold);
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 1px;
    text-transform: uppercase;
    padding: 24px 24px 12px;
}

.nav { flex: 1; overflow-y: auto; padding: 0 12px; }

.nav-link {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 16px;
    color: #a4b4cc;
    text-decoration: none;
    font-size: 14px;
    font-weight: 500;
    border-radius: 8px;
    margin-bottom: 4px;
    transition: 0.2s;
    cursor: pointer;
}

.nav-link:hover {
    background-color: var(--sidebar-hover);
    color: var(--white);
}

.nav-link.active {
    background-color: var(--sidebar-active);
    color: var(--white);
    box-shadow: inset 3px 0 0 var(--gold);
}

.nav-link .icon { font-size: 18px; width: 20px; text-align: center; }

.sidebar-user {
    padding: 20px 24px;
    background-color: rgba(0,0,0,0.15);
    margin: 12px;
    border-radius: 12px;
}

.sidebar-user h4 {
    font-size: 13px;
    font-weight: 600;
    margin-bottom: 4px;
    text-transform: uppercase;
}

.sidebar-user p {
    font-size: 11px;
    color: #a4b4cc;
    margin-bottom: 16px;
}

.sign-out {
    display: flex;
    align-items: center;
    gap: 8px;
    color: var(--white);
    text-decoration: none;
    font-size: 13px;
    font-weight: 500;
}

.main-wrapper {
    margin-left: 260px;
    flex: 1;
    display: flex;
    flex-direction: column;
}

.topbar {
    height: 70px;
    background: var(--white);
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 40px;
    border-bottom: 1px solid #e5e7eb;
}

.topbar h2 {
    font-size: 16px;
    font-weight: 600;
    color: var(--text-main);
}

.topbar-right {
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 14px;
    font-weight: 600;
    color: var(--text-main);
    cursor: pointer;
}

.avatar-small {
    width: 32px;
    height: 32px;
    background-color: #fef3c7;
    color: var(--yellow-text);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 12px;
    font-weight: 700;
}

.content {
    padding: 32px 40px;
    max-width: 1400px;
}

.welcome-banner {
    background: linear-gradient(135deg, var(--blue-banner-start), var(--blue-banner-end));
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    margin-bottom: 24px;
}

.banner-top {
    padding: 32px 40px;
    color: var(--white);
}

.banner-top p {
    font-size: 16px;
    opacity: 0.9;
    margin-bottom: 4px;
}

.banner-top h1 {
    font-size: 36px;
    font-weight: 700;
    display: inline-block;
    position: relative;
    padding-bottom: 8px;
}

.banner-top h1::after {
    content: '';
    position: absolute;
    left: 0; bottom: 0;
    width: 40px; height: 3px;
    background-color: var(--gold);
    border-radius: 2px;
}

.banner-bottom {
    background: var(--white);
    padding: 24px 40px;
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 24px;
}

.info-group {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.info-group label {
    font-size: 12px;
    color: var(--text-muted);
    font-weight: 500;
}

.info-group span {
    font-size: 14px;
    font-weight: 600;
}

.cards-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 24px;
}

.action-card {
    background: var(--white);
    border-radius: 12px;
    padding: 24px;
    display: flex;
    align-items: flex-start;
    gap: 16px;
    text-decoration: none;
    color: inherit;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    border: 1px solid #e5e7eb;
    transition: all 0.2s ease;
}

.action-card:hover {
    box-shadow: 0 10px 15px -3px rgba(0,0,0,0.05);
    transform: translateY(-2px);
}

.card-icon {
    width: 48px;
    height: 48px;
    background-color: #fef3c7;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    color: var(--yellow-text);
    flex-shrink: 0;
}

.card-content { flex: 1; }

.card-header {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 8px;
}

.card-header h3 {
    font-size: 14px;
    font-weight: 600;
    color: var(--text-muted);
}

.badge {
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 600;
}
.badge-yellow { background: var(--yellow-bg); color: var(--yellow-text); }
.badge-gray { background: var(--gray-bg); color: var(--gray-text); }

.card-title {
    font-size: 20px;
    font-weight: 700;
    margin-bottom: 4px;
    color: var(--text-main);
}

.card-desc {
    font-size: 13px;
    color: var(--text-muted);
    line-height: 1.5;
}

.chevron {
    color: #d1d5db;
    font-size: 20px;
    margin-left: auto;
    align-self: center;
}

@media (max-width: 1024px) {
    .cards-grid { grid-template-columns: 1fr; }
    .banner-bottom { flex-direction: column; gap: 16px; }
}
@media (max-width: 768px) {
    .sidebar { transform: translateX(-100%); }
    .main-wrapper { margin-left: 0; }
    .content { padding: 20px; }
    .topbar { padding: 0 20px; }
}
</style>
</head>
<body>
<div class="sidebar">
    <div class="brand">
        <img src="logo.jpg" alt="NKAS Logo">
        <div class="brand-text">NKROFUL AGRICULTURAL<br>SECONDARY TECHNICAL SCHOOL</div>
    </div>
    <div class="portal-label">Student Portal</div>
    <nav class="nav">
        <a class="nav-link active" href="#"><span class="icon">▦</span> Dashboard</a>
        <a class="nav-link" href="#"><span class="icon">▤</span> Check Results</a>
        <a class="nav-link" href="#"><span class="icon">▦</span> Class Timetable</a>
        <a class="nav-link" href="#"><span class="icon">▧</span> Fees & Payments</a>
        <a class="nav-link" href="#"><span class="icon">♙</span> Student Profile</a>
        <a class="nav-link" href="#"><span class="icon">⚙</span> Settings</a>
    </nav>
    <div class="sidebar-user">
        <h4><?= $escape($studentName) ?></h4>
        <p><?= $escape($studentClass) ?></p>
        <a class="sign-out" href="logout.php"><span>⇥</span> Sign Out</a>
    </div>
</div>

<div class="main-wrapper">
    <header class="topbar">
        <h2>Student Dashboard</h2>
        <div class="topbar-right">
            <span><?= $escape($studentName) ?></span>
            <div class="avatar-small"><?= $escape(strtoupper(substr($studentName, 0, 1))) ?></div>
        </div>
    </header>

    <main class="content">
        <div class="welcome-banner">
            <div class="banner-top">
                <p>Good morning,</p>
                <h1><?= $escape($studentName) ?></h1>
            </div>
            <div class="banner-bottom">
                <div class="info-group">
                    <label>Student ID</label>
                    <span><?= $escape($student['student_id']) ?></span>
                </div>
                <div class="info-group">
                    <label>Class</label>
                    <span><?= $escape($studentClass) ?></span>
                </div>
                <div class="info-group">
                    <label>Status</label>
                    <span><?= $escape($student['status']) ?></span>
                </div>
            </div>
        </div>

        <div class="cards-grid">
            <a class="action-card" href="#">
                <div class="card-icon">▤</div>
                <div class="card-content">
                    <div class="card-header">
                        <h3>Academics</h3>
                        <span class="badge badge-gray">Results</span>
                    </div>
                    <div class="card-title">Check Results</div>
                    <p class="card-desc">Access your academic performance and term reports.</p>
                </div>
                <div class="chevron">›</div>
            </a>

            <a class="action-card" href="#">
                <div class="card-icon">▧</div>
                <div class="card-content">
                    <div class="card-header">
                        <h3>Finance</h3>
                        <span class="badge badge-gray">Fees</span>
                    </div>
                    <div class="card-title">Fees & Payments</div>
                    <p class="card-desc">Review fees, payments and outstanding balances.</p>
                </div>
                <div class="chevron">›</div>
            </a>

            <a class="action-card" href="#">
                <div class="card-icon">▦</div>
                <div class="card-content">
                    <div class="card-header">
                        <h3>Schedule</h3>
                        <span class="badge badge-gray">Timetable</span>
                    </div>
                    <div class="card-title">Class Timetable</div>
                    <p class="card-desc">View your weekly class timetable and periods.</p>
                </div>
                <div class="chevron">›</div>
            </a>
        </div>
    </main>
</div>
</body>
</html>
